/** Automatic project verification. All subprocesses execute INSIDE a native host tool. */
import {randomUUID} from 'node:crypto';
import {TeamHostError} from './host-adapter.js';
import {verifierCommand} from './verifier-command.js';
export function createAutoVerifier({executeTool,poison,onPolicy=()=>{}}){
 const states=new Map();
 return {profiles:[],automatic:true,
 preflight(config){if(config.verification?.profileId!=='auto')throw new TeamHostError('AUTO_PROJECT_REQUIRED','请使用 /team 自动探测当前项目。');},
 async collect({config,runId,round,signal,phase='check'}){
  const state=states.get(runId);if(phase!=='baseline'&&!state)throw new TeamHostError('BASELINE_REQUIRED','缺少项目启动快照。');
  if(phase==='check'&&state.project.mode==='analysis-only'&&!state.baselineRef)return {verified:false,analysisOnly:true,checksPassed:false,checksFailed:0,checksRun:false,diffAvailable:false,scopeOk:false,protectedOk:false,reason:state.project.reason,diffStat:'Unavailable',checkSummary:'No independent checks'};
  const nonce=randomUUID(),payload={runId,round,nonce,phase,baselineRef:state?.baselineRef,expectedFingerprint:state?.round===round?state.fingerprint:undefined};
  let result;try{result=await executeTool(config.sessionId,{name:'bash',arguments:{description:'Verify project evidence within the current workspace',command:verifierCommand('project',payload),timeoutMs:90000,run_in_background:false}},signal,{allowUserApproval:true});}catch(error){if(!['CANCELLED','CONTEXT_CHANGED','VERIFIER_UNAVAILABLE','VERIFIER_SCOPE_UNSAFE'].includes(error?.code))poison(config.sessionId);throw error;}
  if(result?.verificationNotDispatched)throw new TeamHostError('VERIFICATION_DENIED','宿主未批准这次项目检查；没有执行检查，也没有自动批准。可在当前会话重新发起 /team。');
  const v=result?.value;if(result?.isError||!v||v.kind!=='foreground'||v.timedOut||v.aborted||v.signal||v.stopped||!Number.isInteger(v.exitCode)||!v.stdout||!v.stderr){poison(config.sessionId);throw new TeamHostError('VERIFICATION_UNSETTLED','自动项目检查的清理状态不明，已暂停新运行。');}
  if(v.stdout?.truncated||v.stderr?.truncated||v.sandbox?.denied||v.sandbox?.runnerFailed)throw new TeamHostError('VERIFICATION_BLOCKED','项目检查被宿主限制或证据过大，无法验证。');
  let data;try{data=JSON.parse(v.stdout.text);}catch{throw new TeamHostError('VERIFICATION_INVALID','项目检查未返回可验证结果。');}
  if(data.unsettled||data.checks?.some(c=>c.unsettled)){poison(config.sessionId);throw new TeamHostError('VERIFICATION_UNSETTLED','检查进程清理未确认，已暂停新运行。');}
  if(data.runId!==runId||data.round!==round||data.nonce!==nonce||v.exitCode!==0||!data.verified)throw new TeamHostError('VERIFICATION_INVALID','项目证据发生变化或不完整，不能宣称完成。');
  if(phase==='baseline'){states.set(runId,{project:data.project,baselineRef:data.baselineRef,config});onPolicy(runId,data.project);return {verified:true,reason:data.project.reason,project:data.project,analysisOnly:data.project.mode==='analysis-only'};}
  if(phase==='check'){state.round=round;state.fingerprint=data.fingerprint;}
  return data;
 },async release(runId){const state=states.get(runId);if(state?.baselineRef){try{await this.collect({config:state.config,runId,round:state.round||0,phase:'cleanup',signal:new AbortController().signal});}catch{/* Evidence contains only project metadata/hashes. Host restrictions may prevent cleanup; never broaden permissions. */}}states.delete(runId);onPolicy(runId,null);}};
}
