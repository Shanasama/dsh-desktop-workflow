import {fileURLToPath} from 'node:url';
const quote=value=>"'"+value.replace(/'/g,"'\\''")+"'";
/** Only fixed package entry URLs may be passed; RPC/model input is serialized as data. */
const entries=Object.freeze({project:new URL('./verification-project-runner.js',import.meta.url),profile:new URL('./verification-host-runner.js',import.meta.url)});
export function verifierCommand(entry,payload){
 if(typeof entry!=='string'||!Object.hasOwn(entries,entry))throw new TypeError('Expected a fixed verifier entry');
 const data=Buffer.from(JSON.stringify(payload),'utf8').toString('base64');
 return (process.versions.electron?'ELECTRON_RUN_AS_NODE=1 ':'')+quote(process.execPath)+' '+quote(fileURLToPath(entries[entry]))+' '+quote(data);
}
