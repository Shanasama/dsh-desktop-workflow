import {test} from 'node:test';
import assert from 'node:assert/strict';
import {verifierCommand} from '../src/verifier-command.js';

test('native verifier invocation admits only fixed package entry names and keeps payload as data',()=>{
  for(const entry of ['../arbitrary.js','constructor','__proto__',new URL('file:///tmp/arbitrary.js'),null,{}])assert.throws(()=>verifierCommand(entry,{}),/fixed verifier entry/);
  const payload={runId:'quote-\'"; touch SHOULD_NOT_RUN',nonce:'fixture',phase:'baseline'};
  for(const [entry,file]of [['project','verification-project-runner.js'],['profile','verification-host-runner.js']]){
    const command=verifierCommand(entry,payload);
    assert.ok(command.includes(file));assert.ok(!command.includes('\n'));assert.ok(!command.includes('touch SHOULD_NOT_RUN'));
    const encoded=command.match(/'([A-Za-z0-9+/=]+)'$/)?.[1];assert.ok(encoded);
    assert.deepEqual(JSON.parse(Buffer.from(encoded,'base64').toString('utf8')),payload);
  }
});
