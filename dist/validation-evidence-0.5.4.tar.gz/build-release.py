from pathlib import Path
import subprocess, tempfile, hashlib, json, shutil, tarfile, os, gzip, io
SOURCE=Path('/workspace/scratch/d2a8bd896b86/dsh-desktop-workflow-v054')
GIT='/tmp/dsh-readonly-review-20261010/.git'
BASE='6069f73b98b922d9db151e2b8637e250c33bbd4c'
OUT=Path('/workspace/shared/dsh-desktop-workflow-v054-release');OUT.mkdir(exist_ok=True)
ROOT_FILES=['.gitignore','INSTALL-ME.md','LICENSE','NOTICE','README.md','SHA256SUMS','cordis.patch.yml','package-lock.json','package.json','tsconfig.json']
ROOT_DIRS=['client','docs','lib','preview','scripts','src','test']
def selected(root):
 files=[root/f for f in ROOT_FILES if (root/f).exists()]
 for d in ROOT_DIRS:
  files += [f for f in (root/d).rglob('*') if f.is_file()]
 for f in files:
  assert not f.is_symlink(),f
  assert not any(x in ['node_modules','.git','.dsh','.env','runtime','.credentials','.lab'] for x in f.relative_to(root).parts),f
 return sorted(files,key=lambda f:str(f.relative_to(root)))
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def inventory(root):return {str(f.relative_to(root)):{'sha256':digest(f),'bytes':f.stat().st_size,'executable':bool(f.stat().st_mode&0o111)} for f in selected(root)}
def run(argv,cwd=None,**kwargs):
 p=subprocess.run(argv,cwd=cwd,check=True,capture_output=True,**kwargs);return p.stdout
# A nonrecursive content checksum inventory replaces the stale baseline inventory.
(SOURCE/'SHA256SUMS').write_text(''.join(f'{digest(f)}  {f.relative_to(SOURCE)}\n' for f in selected(SOURCE) if f.name!='SHA256SUMS'))
snapshot=OUT/'source';snapshot.mkdir(exist_ok=True)
for f in selected(SOURCE):
 dest=snapshot/f.relative_to(SOURCE);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest)
expected=inventory(SOURCE);assert inventory(snapshot)==expected
pkg=json.loads((snapshot/'package.json').read_text());version=pkg['version'];assert version=='0.5.4'
name=pkg['name'];assert name=='dsh-desktop-workflow'
packed=json.loads(run(['npm','pack','--ignore-scripts','--json','--cache','/tmp/dsh-v054-npm-cache','--pack-destination',str(OUT)],snapshot))
install=OUT/packed[0]['filename'];seen=[]
with tarfile.open(install) as tar:
 for m in tar.getmembers():
  assert m.isfile() and m.name.startswith('package/'),m.name
  rel=m.name[len('package/'):];assert rel in expected,rel
  assert tar.extractfile(m).read()==(snapshot/rel).read_bytes(),rel
  seen.append(rel)
assert all(x in seen for x in ['src/orchestrator.js','src/verifier-command.js','src/verification-diagnostics.js','lib/client.js'])
assert 'Enforce the host tool boundary while reviewing a plan' in (snapshot/'src/orchestrator.js').read_text()
# Deterministic source archive; no historical release bundles or dependencies.
archive=OUT/f'{name}-{version}-source.tar.gz';prefix=f'{name}-{version}'
epoch=int(run(['git','--git-dir='+GIT,'show','-s','--format=%ct',BASE]).decode().strip())
with open(archive,'wb') as out,gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=epoch) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for f in selected(snapshot):
  rel=str(f.relative_to(snapshot));data=f.read_bytes();m=tarfile.TarInfo(prefix+'/'+rel);m.size=len(data);m.mode=0o755 if expected[rel]['executable'] else 0o644;m.mtime=epoch;m.uid=m.gid=0;m.uname=m.gname='';tar.addfile(m,io.BytesIO(data))
with tempfile.TemporaryDirectory(prefix='dsh-release-audit-') as tmp:
 temp=Path(tmp);baseline=temp/'baseline';baseline.mkdir();raw=run(['git','--git-dir='+GIT,'archive',BASE])
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(baseline,filter='data')
 # Create a clean baseline-only git index to generate a source-only patch.
 baseline_source=temp/'base-source';baseline_source.mkdir()
 for f in selected(baseline):
  dst=baseline_source/f.relative_to(baseline);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst)
 clean={'PATH':os.environ['PATH'],'HOME':str(temp/'home'),'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':os.devnull,'GIT_TERMINAL_PROMPT':'0'}
 run(['git','init','-q'],baseline_source,env=clean)
 run(['git','add','-f','.'],baseline_source,env=clean)
 run(['git','-c','user.name=Release audit','-c','user.email=audit@example.invalid','-c','commit.gpgSign=false','-c','core.hooksPath='+os.devnull,'commit','-qm','Exact source baseline '+BASE],baseline_source,env=clean)
 for f in selected(baseline_source):f.unlink()
 for f in selected(snapshot):
  dst=baseline_source/f.relative_to(snapshot);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst)
 run(['git','add','-N','-f','.'],baseline_source,env=clean)
 patch=OUT/f'{name}-0.5.3-to-0.5.4.patch';patch.write_bytes(run(['git','diff','--binary','--full-index','HEAD','--','.'],baseline_source,env=clean))
 run(['git','init','-q'],baseline,env=clean)
 run(['git','apply','--check',str(patch)],baseline,env=clean)
 run(['git','apply',str(patch)],baseline,env=clean)
 assert inventory(baseline)==expected,'Patch replay differs from final source'
 unpack=temp/'source-unpack';unpack.mkdir()
 with tarfile.open(archive) as t:t.extractall(unpack,filter='data')
 assert inventory(unpack/prefix)==expected,'Source archive differs from final source'
 baselineInventory=run(['git','--git-dir='+GIT,'ls-tree','-r','--name-only',BASE]).decode().splitlines()
 # Source preserves every baseline file except changed bytes and explicit packaging exclusions.
 assert all(f in expected for f in baselineInventory if not f.startswith('dist/'))
 manifest=OUT/'source-manifest-0.5.4.json';manifest.write_text(json.dumps({'baseCommit':BASE,'version':version,'files':expected},indent=2,ensure_ascii=False)+'\n')
 report={'version':version,'baseCommit':BASE,'sourceFiles':len(expected),'installationFiles':len(seen),'sourceArchiveByteAudit':'pass','installationByteAudit':'pass','patchReplayByteAndModeAudit':'pass','reviewerBoundaryPreserved':True,'excluded':['node_modules','dist historical bundles','.git','credentials','runtime state','test logs'],'sourceTreeSha256':hashlib.sha256(json.dumps(expected,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'artifacts':{f.name:{'sha256':digest(f),'bytes':f.stat().st_size} for f in [install,archive,patch,manifest]}}
 (OUT/'release-audit-0.5.4.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 releaseFiles=[install,archive,patch,manifest,OUT/'release-audit-0.5.4.json']
 (OUT/'SHA256SUMS-0.5.4').write_text(''.join(f'{digest(f)}  {f.name}\n' for f in releaseFiles))
 print(json.dumps(report,indent=2,ensure_ascii=False))
