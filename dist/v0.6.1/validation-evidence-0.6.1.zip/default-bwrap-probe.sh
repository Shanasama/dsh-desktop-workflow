#!/bin/bash
set -eu
# Pin must be set only after the candidate artifact is finalized and approved.
approved_sha256=fdbb46851fe29d7709f3af6549f06514c314b3fbccb45656dfd7d13dd7940969
case "$approved_sha256" in PENDING*) printf '%s\n' 'PROBE NOT RUN: waiting for the final approved 0.6.1 artifact hash.' >&2; exit 2;; esac
probe_dir="$(/usr/bin/mktemp -d /tmp/dsh-production-verifier-v061-probe.XXXXXX)"
/usr/bin/mkdir -p "$probe_dir/home" "$probe_dir/dsh-home"
node_bin=/workspace/shared/dsh-live-runtime/bin/node
clean_path=/workspace/shared/dsh-live-runtime/bin:/usr/local/bin:/usr/bin:/bin
/usr/bin/env -i HOME="$probe_dir/home" PATH="$clean_path" LANG=C.UTF-8 "$node_bin" --version
/usr/bin/env -i HOME="$probe_dir/home" PATH="$clean_path" LANG=C.UTF-8 \
  /bin/bash --noprofile --norc -c 'for tool in bash git bwrap tar; do if tool_path=$(command -v "$tool"); then printf "PREFLIGHT %s=%s\n" "$tool" "$tool_path"; else printf "PREFLIGHT %s=MISSING\n" "$tool"; fi; done'
cd "$probe_dir"
exec /usr/bin/env -i HOME="$probe_dir/home" DSH_HOME="$probe_dir/dsh-home" \
  PATH="$clean_path" LANG=C.UTF-8 \
  DSH_NODE_MODULES=/workspace/scratch/d2a8bd896b86/dsh-workflow-plugin/.lab/node_modules \
  DSH_VERIFIER_TGZ=/workspace/shared/dsh-v061-candidate/dsh-desktop-workflow-0.6.1.tgz \
  DSH_VERIFIER_SHA256="$approved_sha256" \
  "$node_bin" /workspace/shared/dsh-production-verifier-v061-probe.mjs
